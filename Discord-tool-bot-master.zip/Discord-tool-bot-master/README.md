<div align="center">
    <h1>
        Discord Tool Bot<br>
        <img src="https://david-dm.org/JettBurns14/Discord-tool-bot.svg" alt="Dependencies">
        <img src="https://img.shields.io/github/release/JettBurns14/Discord-tool-bot.svg" alt="Releases">
    </h1>
</div>

A utility bot for Discord, built by [Jett Burns](https://github.com/JettBurns14) and [Jonah](https://github.com/Dopest-Pleb).
Contributors:
- [Shadow](https://github.com/ShadowKA)
- [Nate](https://github.com/OctoAvenger)
- [Thomas Li](https://github.com/NovaSagittarii)
