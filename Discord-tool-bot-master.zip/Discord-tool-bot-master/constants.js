const Colors = Object.freeze({
    DEFAULT: "b3b3b3",
    RED: "ff6666",
    GREEN: "00b33c",
    YELLOW: "e6e600",
});

module.exports = {
    Colors,
};